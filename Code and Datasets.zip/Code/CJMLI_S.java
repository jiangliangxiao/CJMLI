import ceka.consensus.ds.DawidSkene;
import ceka.consensus.gtic.GTIC;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.Worker;
import ceka.pc.*;
import ceka.pc.pc_test2.CJMLI;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

public class S {
	static int numWorkers = 20;
	static double min = 0.40;
	static double max = 0.70;
	static int randomSeed = 0;
	static int times=10;
	private static Dataset m_dataset=null;
	private static String[] dataname={
			"anneal",
			"audiology","autos", "balance-scale",
			"biodeg", "breast-cancer", "breast-w", "car",
			"credit-a","credit-g","heart-c", "heart-h",
			"heart-statlog", "hepatitis", "horse-colic","hypothyroid",
			"ionosphere","diabetes", "iris","kr-vs-kp","labor",
			"letter",
			"lymph","mushroom","segment","sick",
			"sonar", "spambase","tic-tac-toe",
			"vehicle","vote",
			"vowel","waveform","zoo"
	};

	public void readData(int m_choose) throws Exception {
		String arffPath="Ceka-v1.0.1/data/myData1/simulation/"+dataname[m_choose]+".arff";
		m_dataset = FileLoader.loadFile(arffPath);

		ReplaceMissingValues m_Missing = new ReplaceMissingValues();
		m_Missing.setInputFormat(m_dataset);
		Instances instances = Filter.useFilter(m_dataset, m_Missing);
		m_dataset = CekaUtils.instancesToDataset(instances,m_dataset);
	}

	public static void main(String[] args) throws Exception {
		String resultPath1 = "D:\\APP\\CEKA\\Ceka-v1.0.1\\src\\ceka\\pc\\pc_test2\\SUni.txt";
		FileOutputStream fs1 = new FileOutputStream(new File(resultPath1));
		PrintStream result1 = new PrintStream(fs1);
		result1.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset","DS","GTIC","IWMV","AALI","LCGTI","TDLI","CJMLI");
		result1.println();

		double meanDS=0;
		double meanGTIC=0;
		double meanIWMV=0;
		double meanAALI=0;
		double meanLCGTI=0;
		double meanTDLI=0;
		double meanCJMLI=0;

		for (int i = 0; i < dataname.length; i++) {

			double accDS=0;
			double accGTIC=0;
			double accIWMV=0;
			double accAALI=0;
			double accLCGTI=0;
			double accTDLI=0;
			double accCJMLI=0;

			for (int time = 0; time < times; time++) {
				m_dataset = null;
				S expriment = new S();
				expriment.readData(i);

				for (int l = 0; l < numWorkers; l++) {
					m_dataset.addWorker(new Worker(l + ""));
				}
				Random random = new Random(randomSeed);
				for (int l = 0; l < numWorkers; l++) {
					double p = (random.nextDouble() * (max - min) + min);
//                    double p = 0.55 + 0.05 * random.nextGaussian();
					simulatedAnnotate(m_dataset, p, l, numWorkers, random);
				}

				//DS
				Dataset datasetDS= CekaUtils.datasetCopy(m_dataset);
				DawidSkene ds = new DawidSkene(50);
				ds.doInference(datasetDS);
				accDS += CekaUtils.integrationAccuracy(datasetDS);
				System.out.println("Integration_DS :"+ CekaUtils.integrationAccuracy(datasetDS));

				//  GTIC
				Dataset datasetGTIC= CekaUtils.datasetCopy(m_dataset);
				GTIC gtic = new GTIC("Ceka-v1.0.1/src/ceka/pc/GTIC2/");
				gtic.doInference(datasetGTIC);
				accGTIC += CekaUtils.integrationAccuracy(datasetGTIC);
				System.out.println("Integration_GTIC:"+ CekaUtils.integrationAccuracy(datasetGTIC));

				//IWMV
				Dataset datasetIWMV= CekaUtils.datasetCopy(m_dataset);
				IWMV iwmv=new IWMV();
				iwmv.doInference(datasetIWMV);
				accIWMV+= CekaUtils.integrationAccuracy(datasetIWMV);
				System.out.println("Integration_IWMV :"+ CekaUtils.integrationAccuracy(datasetIWMV));

                //AALI
                Dataset datasetAALI = CekaUtils.datasetCopy(m_dataset);
                AALI aali = new AALI();
                datasetAALI=aali.doInference(datasetAALI);
                accAALI += CekaUtils.integrationAccuracy(datasetAALI);
                System.out.println("Integration_AALI :"+ CekaUtils.integrationAccuracy(datasetAALI));

				//LCGTI
				Dataset datasetLCGTI=CekaUtils.datasetCopy(m_dataset);
				double a=datasetLCGTI.getExampleSize()/datasetLCGTI.getCategorySize();
				int k=(int)(a*0.5);
				LCGTI my2=new LCGTI();
				my2.doInference(datasetLCGTI,(int)(k),0);
				accLCGTI += CekaUtils.integrationAccuracy(datasetLCGTI);
				System.out.println("LCGTI :"+ CekaUtils.integrationAccuracy(datasetLCGTI));

				//TDLI
				Dataset datasetTDLI = CekaUtils.datasetCopy(m_dataset);
				algorithm_v2 tdli = new algorithm_v2();
				datasetTDLI=tdli.doInference(datasetTDLI);
				accTDLI += CekaUtils.integrationAccuracy(datasetTDLI);
				System.out.println("Integration_TDLI:"+ CekaUtils.integrationAccuracy(datasetTDLI));

				//CJMWV
				Dataset datasetCJMLI = CekaUtils.datasetCopy(m_dataset);
				CJMLI cjmli = new CJMLI();
				cjmli.doInference(datasetCJMLI,70);
				accCJMLI += CekaUtils.integrationAccuracy(datasetCJMLI);
				System.out.println("Integration_new:"+ CekaUtils.integrationAccuracy(datasetCJMLI));

				System.out.println("################################################");
				System.out.println(dataname[i] + " " + time + " fold finshed");
				System.out.println("################################################");
			}

			accDS=accDS/(double)times;
			accGTIC=accGTIC/(double)times;
			accIWMV=accIWMV/(double)times;
			accAALI=accAALI/(double)times;
			accLCGTI=accLCGTI/(double)times;
			accTDLI=accTDLI/(double) times;
			accCJMLI=accCJMLI/(double)times;

			meanDS += accDS;
			meanGTIC +=accGTIC;
			meanIWMV +=accIWMV;
			meanAALI += accAALI;
			meanLCGTI  +=accLCGTI;
			meanTDLI+=accTDLI;
			meanCJMLI+=accCJMLI;

			//性能统计和结果输出
			result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
					accDS,accGTIC,accIWMV,accAALI,accLCGTI,accTDLI,accCJMLI);
			result1.println();
			System.out.println();
		}
		meanDS/=dataname.length;
		meanGTIC/=dataname.length;
		meanIWMV/=dataname.length;
		meanAALI/=dataname.length;
		meanLCGTI/=dataname.length;
		meanTDLI/=dataname.length;
		meanCJMLI/=dataname.length;

		result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
				meanDS,meanGTIC,meanIWMV,meanAALI,meanLCGTI,meanTDLI,meanCJMLI);
		result1.println();
		result1.close();
		System.out.println();
	}
	/**
	 * 稀疏仿标
	 * @param p 工人质量
	 * */
	static void simulatedAnnotate(Dataset dataset, double p, int workerIndex, int numWorkers, Random random) throws Exception {

		double labelProbability;
		labelProbability = 0.1;

		String workerID = dataset.getWorkerByIndex(workerIndex).getId();

		ArrayList<String> willBeLabelExampleId = new ArrayList<>();
		for (int i = 0; i < dataset.getExampleSize(); i++) {
			if (random.nextDouble() < labelProbability) {
				willBeLabelExampleId.add(dataset.getExampleByIndex(i).getId());
				continue;
			}
			if (dataset.getExampleByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize() == 0
					&& workerIndex == numWorkers - 1) {
				willBeLabelExampleId.add(dataset.getExampleByIndex(i).getId());
			}
		}

		int[] label = new int[willBeLabelExampleId.size()];
		for (int i = 0; i < willBeLabelExampleId.size(); i++) {
			if (random.nextDouble() < p) {
				label[i] = 1;
			} else {
				label[i] = 0;
			}
		}

		for (int i = 0; i < label.length; i++) {
			if (label[i] == 1) {
				String labelID = UUID.randomUUID().toString();
				Example example = dataset.getExampleById(willBeLabelExampleId.get(i));
				example.addNoisyLabel(new Label(labelID, String.valueOf(example.getTrueLabel().getValue()),
						example.getId(), workerID));
				dataset.getWorkerByIndex(workerIndex).addNoisyLabel(new Label(null,
						String.valueOf(example.getTrueLabel().getValue()), example.getId(), workerID));
			} else {
				String labelID = UUID.randomUUID().toString();
				Example example = dataset.getExampleById(willBeLabelExampleId.get(i));

				int trueVal = example.getTrueLabel().getValue();
				int res = random.nextInt(dataset.getCategorySize()-1);
				if(res==trueVal) {
					res+=1;
				}

				example.addNoisyLabel(new Label(null, res+"",
						example.getId(), workerID));
				dataset.getWorkerByIndex(workerIndex).addNoisyLabel(new Label(null,
						res+"", example.getId(), workerID));
			}
		}
	}
}
