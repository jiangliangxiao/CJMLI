import ceka.consensus.ds.DawidSkene;
import ceka.consensus.gtic.GTIC;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.pc.*;
import ceka.pc.pc_test2.CJMLI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class R {
	private static  Dataset m_dataset=null;
	private  static  int  m_nFold=10;
	private static String[] dataname = {"labelme"};
	private static String dataDir = "D:\\APP\\CEKA\\Ceka-v1.0.1\\data\\myData1\\real\\";
	public static Dataset readDataset(int m_choose) throws Exception {
		String responsepath = dataDir + dataname[m_choose] + "\\" + dataname[m_choose] + ".response.txt";
		String goldpath = dataDir + dataname[m_choose] + "\\" + dataname[m_choose] + ".gold.txt";
		String arffxpath = dataDir + dataname[m_choose] + "\\" + dataname[m_choose] + ".arffx";
		String arffpath = dataDir + dataname[m_choose] + "\\" + dataname[m_choose] + ".arff";

		Dataset dataset;
		try {
			dataset = FileLoader.loadFileX(responsepath, goldpath, arffxpath);
		} catch (Exception e) {
			dataset = FileLoader.loadFile(responsepath, goldpath, arffpath);
		}
		return dataset;

	}

	public static void main(String[] args) throws Exception {


		String resultPath1 = "D:\\APP\\CEKA\\Ceka-v1.0.1\\src\\ceka\\pc\\pc_test2\\R.txt";
		FileOutputStream fs1 = new FileOutputStream(new File(resultPath1));
		PrintStream result1 = new PrintStream(fs1);
		result1.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset",  "DS", "GTIC","IWMV","AALI","LCGTI","TDLI","CJMLI");
		result1.println();

		double meanDS=0;
		double meanGTIC=0;
		double meanIWMV=0;
		double meanAALI=0;
		double meanLCGTI=0;
		double meanTDLI=0;
		double meanCJMLI=0;

		for(int i=0;i<dataname.length;i++){
			double accDS=0;
			double accGTIC=0;
			double accIWMV=0;
			double accAALI=0;
			double accLCGTI=0;
			double accTDLI=0;
			double accCJMLI=0;

			R expriment = new R();
			Dataset dataset=expriment.readDataset(i);
			// 读取数据集
			Dataset m_dataset = readDataset(i);
			for (int nFold = 0; nFold < m_nFold; nFold++) {
				//DS
				Dataset datasetDS= CekaUtils.datasetCopy(m_dataset);
				DawidSkene ds = new DawidSkene(50);
				ds.doInference(datasetDS);
				accDS += CekaUtils.integrationAccuracy(datasetDS);
				System.out.println("Integration_DS :"+ CekaUtils.integrationAccuracy(datasetDS));

				//GTIC
				Dataset datasetGTIC= CekaUtils.datasetCopy(m_dataset);
				GTIC gtic = new GTIC("Ceka-v1.0.1/src/ceka/pc/GTIC2/");
				gtic.doInference(datasetGTIC);
				accGTIC += CekaUtils.integrationAccuracy(datasetGTIC);
				System.out.println("Integration_GTIC:"+ CekaUtils.integrationAccuracy(datasetGTIC));

				// IWMV
				Dataset datasetIWMV= CekaUtils.datasetCopy(m_dataset);
				IWMV iwmv=new IWMV();
				iwmv.doInference(datasetIWMV);
				accIWMV+= CekaUtils.integrationAccuracy(datasetIWMV);
				System.out.println("Integration_IWMV :"+ CekaUtils.integrationAccuracy(datasetIWMV));

				// AALI
				Dataset datasetAALI = CekaUtils.datasetCopy(m_dataset);
				AALI aali = new AALI();
				datasetAALI=aali.doInference(datasetAALI);
				accAALI += CekaUtils.integrationAccuracy(datasetAALI);
				System.out.println("AALI :"+ CekaUtils.integrationAccuracy(datasetAALI));

				//LCGTI
				Dataset datasetLCGTI=CekaUtils.datasetCopy(m_dataset);
				double a=datasetLCGTI.getExampleSize()/datasetLCGTI.getCategorySize();
				int k=(int)(a*0.5);
				LCGTI my2=new LCGTI();
				my2.doInference(datasetLCGTI,(int)(k),0);
				accLCGTI += CekaUtils.integrationAccuracy(datasetLCGTI);
				System.out.println("LCGTI :"+ CekaUtils.integrationAccuracy(datasetLCGTI));

				//TDLI
				Dataset datasetTDLI = CekaUtils.datasetCopy(m_dataset);
				algorithm_v2 tdli = new algorithm_v2();
				datasetTDLI=tdli.doInference(datasetTDLI);
				accTDLI += CekaUtils.integrationAccuracy(datasetTDLI);
				System.out.println("Integration_TDLI:"+ CekaUtils.integrationAccuracy(datasetTDLI));

				//CJMLI
				Dataset datasetCJMLI = CekaUtils.datasetCopy(m_dataset);
				CJMLI cjmli = new CJMLI();
				cjmli.doInference(datasetCJMLI,70);
				accCJMLI += CekaUtils.integrationAccuracy(datasetCJMLI);
				System.out.println("Integration_new:"+ CekaUtils.integrationAccuracy(datasetCJMLI));

				System.out.println(dataname[i]+" "+nFold+" fold finshed");
				System.out.println("################################################");
			}

			accDS=accDS/(double)m_nFold;
			accGTIC=accGTIC/(double)m_nFold;
			accIWMV=accIWMV/(double)m_nFold;
			accAALI=accAALI/(double)m_nFold;
			accLCGTI=accLCGTI/(double)m_nFold;
			accTDLI=accTDLI/(double)m_nFold;
			accCJMLI=accCJMLI/(double)m_nFold;

			meanDS += accDS;
			meanGTIC +=accGTIC;
			meanIWMV +=accIWMV;
			meanAALI +=accAALI;
			meanLCGTI+=accLCGTI;
			meanTDLI+=accTDLI;
			meanCJMLI+=accCJMLI;

			result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
					accDS,accGTIC,accIWMV,accAALI,accLCGTI,accTDLI,accCJMLI);
			result1.println();
			System.out.println();
		}
		meanDS/=dataname.length;
		meanGTIC/=dataname.length;
		meanIWMV/=dataname.length;
		meanAALI/=dataname.length;
		meanLCGTI/=dataname.length;
		meanTDLI/=dataname.length;
		meanCJMLI/=dataname.length;

		result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
				meanDS,meanGTIC,meanIWMV,meanAALI,meanLCGTI,meanTDLI,meanCJMLI);
		result1.println();
		result1.close();
		System.out.println();
	}
}
