import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import ceka.consensus.MajorityVote;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.Worker;
import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Utils;

import java.util.concurrent.*;

public class CJMLI {

	int K;
	int randomSeed=0;
	HashMap<String,Double> workerQuality;
	HashMap<Integer, Double> workerQualitySumInKGroup;
	HashMap<Integer, Integer> workerLabelSumInKGroup;

	int[][][] matrix;

	public void doInference(Dataset dataset,int K) {
		this.K = K;
		int R = dataset.getWorkerSize();
		int N = dataset.getExampleSize();

		workerQualitySumInKGroup = new HashMap<>();
		workerLabelSumInKGroup = new HashMap<>();

		double count = 0;
		for(int i=0;i<dataset.getExampleSize();i++) {
			count+=dataset.getExampleByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize();
		}
		System.out.println("K="+this.K);

		Random random = new Random(randomSeed);
		matrix = new int[K][N][R];

		for(int k=0;k<K;k++) {
			for (int i = 0; i < N; i++) {
				Example example = dataset.getExampleByIndex(i);
				for (int j = 0; j < R; j++) {
					Worker worker = dataset.getWorkerByIndex(j);
					if(random.nextDouble()<0.5) {
						matrix[k][i][j] = 1;
						if(example.getNoisyLabelByWorkerId(worker.getId())==null) {
							matrix[k][i][j] = 0;
						}
					}else {
						matrix[k][i][j] = 0;
					}
				}
			}
		}
		
		MajorityVote mv = new MajorityVote();
		mv.doInference(dataset);
		
		workerQuality = new HashMap<>();
		for(int r=0;r<dataset.getWorkerSize();r++) {
			Worker worker = dataset.getWorkerByIndex(r);
			double fenzi=0,fenmu=0;
			for(int i=0;i<dataset.getExampleSize();i++) {
				Example example = dataset.getExampleByIndex(i);
				if(example.getNoisyLabelByWorkerId(worker.getId())==null) {
					continue;
				}else {
					fenmu+=1.0;
					if(example.getIntegratedLabel().getValue()==example.getNoisyLabelByWorkerId(worker.getId()).getValue()) {
						fenzi+=1.0;
					}
				}
			}
			double quality;
			if(Utils.eq(fenmu, 0.0)) {
				quality = 0.0;
			}else {
				quality = fenzi/fenmu;
			}
			workerQuality.put(worker.getId(), quality);
		}
		Classifier[] classifiers = new Classifier[K];
		
		/*********提交任务到线程池，并行建树提高速度*********/
		ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		List<Future<Classifier>> futures = new ArrayList<>();
		for (int k = 0; k < K; k++) {
			final int kk = k;
			futures.add(executor.submit(() -> getClassifierByGroupedFrep_J48(dataset,kk)));
		}
		
		for (int k = 0; k < K; k++) {
			try {
				classifiers[k] = futures.get(k).get(); 
				if(k%20==0 && k!=0) {
					System.out.print(k+"/"+K+" ");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		executor.shutdown();
		try {
			executor.awaitTermination(1, TimeUnit.HOURS); 
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println();
		/******提交任务到线程池，并行建树提高速度*********/
		
		for(int i=0;i<dataset.getExampleSize();i++) {
			Example example = dataset.getExampleByIndex(i);
			double[] classCounts = new double[dataset.getCategorySize()];
			for(int j=0;j<K;j++) {
				Classifier classifier = classifiers[j];

				try {
					double[] probs = classifier.distributionForInstance(example);
					int predictedClass = (int) classifier.classifyInstance(example);
					double weight = (predictedClass >= 0 && predictedClass < probs.length) ? probs[predictedClass] : 0;
					classCounts[predictedClass] += weight;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			int y = Utils.maxIndex(classCounts);
			example.setIntegratedLabel(new Label(null, y+"", example.getId(), "New"));
		}
		dataset.assignIntegeratedLabel2WekaInstanceClassValue();
	}

	/**
	 * @param k 当前第几组
	 */
	private Classifier getClassifierByGroupedFrep_J48(Dataset dataset, int k)  {


		Dataset extend_dataset = new Dataset(dataset, 0);

		//遍历所有实例，找出要使用的实例
		for (int i = 0; i < dataset.getExampleSize(); i++) {
			Example example = dataset.getExampleByIndex(i);
			//存储实例的加权类概率分布
			double[] labelDistribution = new double[dataset.getCategorySize()];
			for(int r=0;r<dataset.getWorkerSize();r++) {
				Worker worker = dataset.getWorkerByIndex(r);
				
				if (matrix[k][i][r]==1) {
					workerLabelSumInKGroup.put(k, workerLabelSumInKGroup.getOrDefault(k, 0)+1);
					workerQualitySumInKGroup.put(k, workerQualitySumInKGroup.getOrDefault(k, 0.0)+workerQuality.get(worker.getId()));
					int value = example.getNoisyLabelByWorkerId(worker.getId()).getValue();
					labelDistribution[value] += workerQuality.get(worker.getId());
				}
			}
			double sum = Utils.sum(labelDistribution);
			if (Utils.eq(sum, 0.0)) {
				continue;
			}
			for (int j = 0; j < labelDistribution.length; j++) {
				labelDistribution[j] = (labelDistribution[j]) / (sum);
			}
			for (int j = 0; j < labelDistribution.length; j++) {
				if(Utils.eq(0.0, labelDistribution[j])) {
					continue;
				}
				Example example1 = new Example(example, UUID.randomUUID().toString());
				example1.setWeight(labelDistribution[j]);
				example1.setIntegratedLabel(new Label(null, j+"", example1.getId(), "null"));
				extend_dataset.addExample(example1);
			}
		}
		
		extend_dataset.assignIntegeratedLabel2WekaInstanceClassValue();
		J48 j48 = new J48();
		
		try {
			j48.buildClassifier(extend_dataset);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return j48;
	}
}
